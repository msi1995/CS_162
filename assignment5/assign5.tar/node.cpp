#include "node.h"

Node::Node() {

}

Node::~Node() {

}