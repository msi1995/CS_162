#include "bats.h"
#include <iostream>
using namespace std;

Bats::Bats() {

}

Bats::~Bats() {

}

void Bats::encounter() {

	cout << endl << endl << "You enter the room and are greeted by the deafening screech of hundreds of superbats." << endl;
	cout << "The bats latch on to you, and have carried you to another room in the labyrinth..." << endl << endl;


}

void Bats::percept() {

	cout << "You hear wings flapping nearby..." << endl << endl;

}