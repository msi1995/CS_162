#include <iostream>
#include "event.h"
using namespace std;

Event::Event() {

}

Event::~Event() {

}

void Event::percept() {

}

void Event::encounter() {

}