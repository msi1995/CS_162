#include <iostream>
#include "Hand.h"
#include "card.h"
#include "deck.h"
#include "player.h"

//Default Constructor, makes name "Computer Player" if a name isn't entered (cpu)
Player::Player() {
	name = "Computer Player";
}

//Destructor
Player::~Player() {

}

//Allows the player to enter their name when called. Used when displaying hand
void Player::get_name() {
	cout << "Enter player name: ";
	getline(cin, name);
}

//Populates a hand array with 7 cards from the shuffled game deck.
void Player::create_phand(Deck& game_deck) {
	for (int i = 0; i < 7; i++) {
		hand.get_card()[i] = game_deck.draw_card();
	}
}

// Prints a player's hand after population.
void Player::print_phand() {
	cout << endl << name << ", your current hand is:" << endl << endl;
	for (int i = 0; i < hand.hand_size(); i++) {
		if (hand.get_card()[i].get_rank() == 0)
			cout << "(Card " << i + 1 << "): " "Ace of ";
		else if (hand.get_card()[i].get_rank() == 10)
			cout << "(Card " << i + 1 << "): " "Jack of ";
		else if (hand.get_card()[i].get_rank() == 11)
			cout << "(Card " << i + 1 << "): " "Queen of ";
		else if (hand.get_card()[i].get_rank() == 12)
			cout << "(Card " << i + 1 << "): " "King of ";
		else if (hand.get_card()[i].get_rank() != 1000)
			cout << "(Card " << i + 1 << "): " << hand.get_card()[i].get_rank() + 1 << " of ";
		else
			cout << "" << endl;


		if (hand.get_card()[i].get_suit() == 0)
			cout << "Spades" << endl;
		else if (hand.get_card()[i].get_suit() == 1)
			cout << "Hearts"<< endl;
		else if (hand.get_card()[i].get_suit() == 2)
			cout << "Diamonds"<< endl;
		else if (hand.get_card()[i].get_suit() == 3)
			cout << "Clubs"<< endl;
		else if (hand.get_card()[i].get_suit() == 1000)
			cout << " ";

	}
}

// Prompts the user for an input which is then used to determine what move they wish to make.
int Player::prompt() {
	int playthiscard;
	cout << "What card would you like to play? Press 1, 2, 3 etc or 0 to draw a card. Card must be an 8 or match the rank or suit of top card! ";

		cin >> playthiscard;
		return playthiscard;
}

//Checks validity of the card player chooses and sets that card as the topcard. Draws a card if the player 
// elects to draw rather than placing a card. Cards are drawn from the "cards" deck in the Game class, which
// is a copy of the 38 cards remaining in the shuffled game deck after 14 cards were dealt out.
void Player::play_card_valid(Deck& topcard, Deck& cards, int& deck_marker, int& hand_size) {
	int flag = 1;
	int declare_suit;
	while (flag == 1) {
		int choice = prompt();
		if (choice == 0) {
			hand.get_card()[hand_size] = cards.get_card()[deck_marker];
			deck_marker--;
			hand_size++;
			print_phand();
			play_card_valid(topcard, cards, deck_marker, hand_size);
		}

		int hand_rank = hand.get_card()[choice - 1].get_rank();
		int topcard_rank = topcard.get_card()[0].get_rank();
		int hand_suit = hand.get_card()[choice - 1].get_suit();
		int topcard_suit = topcard.get_card()[0].get_suit();

		if ((hand_rank == topcard_rank) || (hand_suit == topcard_suit) || (hand_rank == 7)) {
			flag = 0;
			topcard.get_card()[0] = hand.get_card()[choice - 1];

			if (hand_rank == 7) {
				cout << "Crazy Eight!!! Declare a suit (0: Spades | 1: Heart | 2: Diamonds | 3 Clubs): ";
				cin >> declare_suit;
				topcard.get_card()[0].set_rank(7);
				topcard.get_card()[0].set_suit(declare_suit);
				flag = 0;
				break;
			}
		}
	}
}

//Checks validity of the card the CPU chooses and sets that card as the topcard. Same functionality
// as the function above, but no user input is taken. rand() is used instead.
void Player::cpu_play_card_valid(Deck& topcard, Deck& cards, int& deck_marker, int& cpu_hand_size) {
	int flag = 1;
	int declare_suit;
		for(int i = 0; i < 7; i++){
			int hand_rank = hand.get_card()[i].get_rank();
			int topcard_rank = topcard.get_card()[0].get_rank();
			int hand_suit = hand.get_card()[i].get_suit();
			int topcard_suit = topcard.get_card()[0].get_suit();
			if ((hand_rank == topcard_rank) || (hand_suit == topcard_suit)) {
				flag = 0;
				topcard.get_card()[0] = hand.get_card()[i];
				break;
			}

			else if (hand_rank == 7) {
					flag = 0;
					topcard.get_card()[0].set_rank(7);
					topcard.get_card()[0].set_suit(rand() % 3);
					break;
				}

			// This was an attempt at making the CPU draw cards properly. It was causing
			// errors that I couldn't seem to fix.
			/*else{
				hand.get_card()[cpu_hand_size] = cards.get_card()[deck_marker];
				deck_marker--;
				cpu_hand_size++;
				play_card_valid(topcard, cards, deck_marker, cpu_hand_size);
			}*/
		}
		cout << endl << endl << "Computer Player made the new ";
	}